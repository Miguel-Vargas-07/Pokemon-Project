/**
 * This code adapted from
 * @author Laurie White
 * index of my name is 
 * substring 
 * -------
 * SUMMARIZE SOURCES YOU CONSULTED HERE
 * You are expected to attempt this work on your own
 * And to completely understand all code you submit
 * If you consulted any people, websites, etc, you must list the source here.
 * You must also add in-line comments that explain what code is yours
 * 
 */
 import java.util.Scanner;
public class Chatbot
{
	/**
	 * Gets a default greeting.
	 * @return String
	 */
	public String greeting()
	{
		return "What do you got in mind today?";
	}
	/**
	 * variables
	 */
	 String color = "never given ";
	 String name = "never given ";
	 String pet = "never given ";
	 String petName = "never given";
	 String like = "never given";
	
	/**
	 * Resturns a response to a user statement
	 * 
	 * @param statement
	 * @return String
	 */
	public String getResponse(String statement)
	{
		String response = "";
		
		 if (statement.indexOf("dog")>=0 ||
		 statement.indexOf("cat")>=0
		 )
		 {response = "Tell me more about your pets";
		     
		 }
		else if(
		    statement.indexOf("dog") >= 0 ||
		    statement.indexOf("cat") >= 0 
		)
		{
		        response = "Tell me more about your pets";
		} else if(
		    statement.indexOf("mr") >= 0 
		 )
		 {
		     response = "Tell me more about him";
		 } else if(
		     
		    statement.indexOf("mrs") >= 0 
		 )
		 {
		     response = "Tell me more about her";
		 } else if(
		     
		    statement.indexOf("mx") >= 0
		 )
		 {
		     response = "What else are they like?";
		 } else if (
		     statement.indexOf("pizza")>= 0 ||
		     statement.indexOf("pasta")>= 0 
		     
		 )
		 {
		     response = " mmmmmm. I love italian food, whats your favorite italian place?";
		 }else if (
		     statement.indexOf("soccer")>= 0 ||
		     statement.indexOf("basketball")>= 0 ||
		     statement.indexOf("football")>= 0 
		 )
		 {
		     response = "tell more about your sport, how many times do you train a week?";
		 }else if (
		     statement.indexOf("burger") >= 0 ||
		     statement.indexOf("hotdog") >= 0 
		 )
		 {
		     response = "yummm, what is your favorite fast food place?";
		 } else if (
		     statement.indexOf("popeyes") >= 0 ||
		     statement.indexOf("wendys") >= 0 
		 )
		 {
		     response = "I like fast food too, what do you usually get from the menu? ";
		 }else if (
		     statement.indexOf("my name is")>= 0
		 )
		 {
		     name = statement.substring(11);
		     response = "Hi "+ name;
		 }
		 else if (
		     statement.indexOf("my favorite color is")>= 0 
		 )
		 {
            color = statement.substring(20);		    
		     response = "I like " + color + " too.";
		 }
		 else if (
		     statement.indexOf("what is my favorite color")>= 0
		 )
		 {
		     response = "Your favorite color is "+ color;
		 }else if (
		     statement.indexOf("what is my name ")>= 0
		 )
		 {
		     response = "Your name is "+ name;
		 }else if (
		     statement.indexOf("my pet is a")>= 0
		 )
		 {
		     pet = statement.substring(11);
		     response = "I like "+ pet +"s";
		 }else if (
		    statement.indexOf("my pets name is")>= 0
		 )
		 {
		     petName = statement.substring(15);
		     response = "I bet "+ petName + " is a good pet";
		 }else if (
		    statement.indexOf("what is my pets name")>= 0    
		 )
		 {
		     response = "Your "+ pet + " is named "+ petName;
		 }else if (
		    statement.indexOf("what do you know about me?")>= 0    
		 )
		 {
		     response = "Your name was "+ name + "Your favorite color was " + color + "Your " + pet + "name is "+ petName +" and you like "+ like;
		 }else if (
		    statement.indexOf("I like")>= 0    
		 )
		 {
		     like = statement.substring(7);
		     response = "I like "+ like + " too. ";
		 }else if (
		    statement.indexOf("what do i like?")>= 0   
		 )
		 {
		     response = "you like "+ like;
		 }
		 
		 else if 
		 (statement.trim().equals(""))
		 {
		     response = "say something please ";
		 }
		 
		 else if (
		    statement.indexOf("mother") >= 0 ||
		    statement.indexOf("brother") >= 0 ||
		    statement.indexOf("sister") >= 0 ||
		    statement.indexOf("father") >= 0
		)
	    {
	        response = "Tell me more about your family!";
	    } else if (
	        statement.indexOf("weather") >= 0 ||
		    statement.indexOf("sun") >= 0 ||
		    statement.indexOf("rain") >= 0
        )
        {
            response = "The weather here is really nice.";
        }else if (
            statement.indexOf("no")>=0
        )
        {
            response = "don't be so negative";
        }
        
        
        else {
            response = randomResponse();
        }
		return response;
	}

	/**
	 * Pick a default response to use if nothing else fits.
	 * @return String
	 */
	private String randomResponse()
	{
		int NUMBER_OF_RESPONSES = 11;
		double responseIndex = Math.random();
		int whichResponse = (int)(responseIndex * NUMBER_OF_RESPONSES);
		String response = "";
		
		if (whichResponse == 0)
		{
			response = "Very cool!";
		}
		else if (whichResponse == 1)
		{
			response = "Tell me more about that.";
		}
		else if (whichResponse == 2)
		{
			response = "That's really interesting!";
		}
		else if (whichResponse == 3)
		{
			response = "Can we talk about something else?";
		}
		else if (whichResponse == 4)
		{
			response = "Booooring.";
		}
		else if (whichResponse == 5)
		{
			response = "You really like to talk, don't you?";
		}
		else if (whichResponse == 6)
		{
		    response = "Thats pretty cool, but could you tell me if you have any pets?";
		}
		else if (whichResponse == 7)
		{
		    response = "huh, do you have any sibilings?";
		}
		else if (whichResponse == 8)
		{
		    response = "thats cool, can you tell me more about your parents?";
		}
		else if (whichResponse == 9)
		{
		    response = "what about this, tell me about your favorite male teacher";
		}
		else if (whichResponse == 10)
		{
		    response = " thats fascinating, but can you tell me about your favortie female teacher?";
		}
		else if (whichResponse == 11)
		{
		    response = " wow, tell me about your favorite non binary teacher";
		}
		return response;
	}
}